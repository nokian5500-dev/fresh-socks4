#include "about.h"
#include "ui_about.h"
#include "proxychainsgui.h"
#include "ui_proxychainsgui.h"
#include "settings.h"
#include "ui_settings.h"
#include "license.h"
#include "ui_license.h"

about::about(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::about)
{
    ui->setupUi(this);
    dLicense = new license (this);
}

about::~about()
{
    delete ui;
}

void about::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}



void about::closeEvent(QCloseEvent *event)
{
        hide();
        event->ignore();
}
void about::on_close_button_clicked()
{
    hide();
}

void about::on_license_button_clicked()
{
    dLicense->show();
}


void about::on_commandLinkButton_clicked()
{
    QDesktopServices::openUrl(QUrl(tr("http://proxychainsgui.sourceforge.net")));
}

void about::on_commandLinkButton_2_clicked()
{
    QDesktopServices::openUrl(QUrl(tr("http://proxychains.sourceforge.net")));
}
