#include "settings.h"
#include "ui_settings.h"
#include "proxychainsgui.h"
#include "ui_proxychainsgui.h"

settings::settings(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::settings)
{
    ui->setupUi(this);
    ui->treeWidget->setColumnWidth(0, 20);
    ui->treeWidget->setColumnWidth(2, 110);
    ui->treeWidget->setColumnWidth(3, 55);
    ui->treeWidget->setColumnWidth(4, 120);
    ui->treeWidget->setColumnWidth(5, 120);

//************************Parsing config file*************************************

    QFile conf_file("/etc/proxychains.conf");
    QString index;
    if ( conf_file.open(QIODevice::ReadOnly | QIODevice::Text) )
    {
    QTextStream in_conf(&conf_file);
    in_conf.setCodec("UTF-8");

     if (!conf_file.exists())
    {
    QMessageBox::critical( this, "Warning!", "Unable to find the /etc/proxychains.conf!" );
    conf_file.close();
    }

      while ( !in_conf.atEnd() ) {

           index = in_conf.readLine();


           if (index.contains(QRegExp("^s[t]rict_chain")))
           {
                ui->strict_radio->setChecked(true);
           }
           if (index.contains(QRegExp("^r[a]ndom_chain")))
           {
                ui->random_radio->setChecked(true);
           }
           if (index.contains(QRegExp("^d[y]namic_chain")))
           {
                ui->dynamic_radio->setChecked(true);
           }
           if (index.contains(QRegExp("^p[r]oxy_dns")))
           {
               ui->dns_chk->setChecked(true);
           }
           if (index.contains(QRegExp("^c[h]ain_len")))
           {
               int j = 0;
               while ((j = index.indexOf("=", j)) != -1) 
                   {
                       ui->lenth_spin->setEnabled(true);
                       QString str = index.mid(j+1, 10);
                       //qDebug() << "Found <b> tag at index position" << j << str.trimmed();
                       QString chain_len = str.trimmed();
                       ui->lenth_spin->setValue(chain_len.toInt());
                       ++j;
                   }
           }
           if (index.contains(QRegExp("^t[c]p_read_time_out")))
           {
               int j = 0;
               while ((j = index.indexOf("ut", j)) != -1)
                   {
                       QString str = index.mid(j+2, 10);
                       QString tcp_read = str.trimmed();
                       ui->tcp_read_spin->setValue(tcp_read.toInt());
                       ++j;
                   }
           }
           if (index.contains(QRegExp("^t[c]p_connect_time_out")))
           {
               int j = 0;
               while ((j = index.indexOf("ut", j)) != -1)
                   {
                       QString str = index.mid(j+2, 10);
                       QString tcp_connect = str.trimmed();
                       ui->tcp_con_spin->setValue(tcp_connect.toInt());
                       ++j;
                   }
           }
           if (index.contains(QRegExp("^socks[4]")) || index.contains(QRegExp("^#socks[4]")))
           {
                   // qDebug() << "socks4";
                   QTreeWidgetItem *item = new QTreeWidgetItem(ui->treeWidget);
                   item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
                   if (index.contains(QRegExp("^socks[4]")))
                   {
                   item->setCheckState(0, Qt::Checked);
                   }
                   else
                   {
                   item->setCheckState(0, Qt::Unchecked);
                   }
                   QStringList strlist = index.split(QRegExp("\\s"), QString::SkipEmptyParts);
                   if (index.contains(QRegExp("^#socks[4]")))
                   {
                       QString type = strlist.at(0);
                       item->setText(1, type.mid(1, type.length()));
                   }
                   else
                   {
                       item->setText(1, strlist.at(0));
                   }
                   item->setText(2, strlist.at(1));
                   item->setText(3, strlist.at(2));
                   if (strlist.size() > 3){
                   item->setText(4, strlist.at(3));
                   }
                   if (strlist.size() > 4) {
                       item->setText(5, strlist.at(4));
                   }

           }
           if (index.contains(QRegExp("^socks[5]")) || index.contains(QRegExp("^#socks[5]")))
           {
              // qDebug() << "socks5";
               QTreeWidgetItem *item = new QTreeWidgetItem(ui->treeWidget);
               item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
               if (index.contains(QRegExp("^socks[5]")))
               {
               item->setCheckState(0, Qt::Checked);
               }
               else
               {
               item->setCheckState(0, Qt::Unchecked);
               }
               QStringList strlist = index.split(QRegExp("\\s"), QString::SkipEmptyParts);
               if (index.contains(QRegExp("^#socks[5]")))
               {
                   QString type = strlist.at(0);
                   item->setText(1, type.mid(1, type.length()));
               }
               else
               {
                   item->setText(1, strlist.at(0));
               }
               item->setText(2, strlist.at(1));
               item->setText(3, strlist.at(2));
               if (strlist.size() > 3){
               item->setText(4, strlist.at(3));
               }
               if (strlist.size() > 4) {
                   item->setText(5, strlist.at(4));
               }

           }
           if (index.contains(QRegExp("^h[t]tp")) || index.contains(QRegExp("^#h[t]tp")))
           {
             // qDebug() << "http";
              QTreeWidgetItem *item = new QTreeWidgetItem(ui->treeWidget);
              item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
              if (index.contains(QRegExp("^h[t]tp")))
              {
              item->setCheckState(0, Qt::Checked);
              }
              else
              {
              item->setCheckState(0, Qt::Unchecked);
              }
              QStringList strlist = index.split(QRegExp("\\s"), QString::SkipEmptyParts);
              if (index.contains(QRegExp("^#h[t]tp")))
              {
                  QString type = strlist.at(0);
                  item->setText(1, type.mid(1, type.length()));
              }
              else
              {
                  item->setText(1, strlist.at(0));
              }
              item->setText(2, strlist.at(1));
              item->setText(3, strlist.at(2));
              if (strlist.size() > 3){
              item->setText(4, strlist.at(3));
          }
              if (strlist.size() > 4) {
                  item->setText(5, strlist.at(4));
              }

           }
           
         }

     conf_file.close();
     }

//********************************************************************************
}

settings::~settings()
{
    delete ui;
}

void settings::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void settings::closeEvent(QCloseEvent *event)
{
        hide();
        event->ignore();
}

void settings::on_add_button_clicked()
{
    QTreeWidgetItem *item = new QTreeWidgetItem(ui->treeWidget);
    item->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
    item->setCheckState(0, Qt::Checked);
    ui->treeWidget->clearSelection();
    item->setSelected(true);

    
}

void settings::on_del_button_clicked()
{
    QTreeWidgetItem *item = ui->treeWidget->currentItem();
    if (item->isSelected())
    {
    delete item;
    }
}



void settings::on_random_radio_pressed()
{
    ui->lenth_spin->setEnabled(true);
}

void settings::on_strict_radio_pressed()
{
    ui->lenth_spin->setEnabled(false);
}

void settings::on_dynamic_radio_pressed()
{
    ui->lenth_spin->setEnabled(false);
}

void settings::on_save_button_clicked()
{
    QString index;
    QString pre_release;
    QFile conf_file("/etc/proxychains.conf");
    if (conf_file.open(QIODevice::ReadOnly | QIODevice::WriteOnly | QIODevice::Text))
    {
    QTextStream in_conf(&conf_file);
    in_conf.setCodec("UTF-8");
     while ( !in_conf.atEnd() )
    {

         index = in_conf.readLine()+"\n";

         if (index.contains(QRegExp("^s[t]rict_chain")) || index.contains(QRegExp("^#s[t]rict_chain")))
         {
             index.remove(0, index.length());
             if (ui->strict_radio->isChecked())
             {
              index.insert(0,"strict_chain\n");
             }
             else
             {
              index.insert(0,"#strict_chain\n");
             }
         }
         if (index.contains(QRegExp("^r[a]ndom_chain")) || index.contains(QRegExp("^#r[a]ndom_chain")))
                      {
                          index.remove(0, index.length());
                          if (ui->random_radio->isChecked())
                          {
                           index.insert(0,"random_chain\n");
                          }
                          else
                          {
                           index.insert(0,"#random_chain\n");
                          }
                      }
         if (index.contains(QRegExp("^d[y]namic_chain")) ||  index.contains(QRegExp("^#d[y]namic_chain")))
                          {
                              index.remove(0, index.length());
                              if (ui->dynamic_radio->isChecked())
                              {
                               index.insert(0,"dynamic_chain\n");
                              }
                              else
                              {
                               index.insert(0,"#dynamic_chain\n");
                              }
                          }
         if (index.contains(QRegExp("^p[r]oxy_dns")) || index.contains(QRegExp("^#p[r]oxy_dns")))
                              {
                                  index.remove(0, index.length());
                                  if (ui->dns_chk->isChecked())
                                  {
                                   index.insert(0,"proxy_dns\n");
                                  }
                                  else
                                  {
                                   index.insert(0,"#proxy_dns\n");
                                  }
                              }
                              if (index.contains(QRegExp("^c[h]ain_len")) || index.contains(QRegExp("^#c[h]ain_len")))
                                  {
                                     index.remove(0, index.length());
                                     if (ui->random_radio->isChecked())
                                     {
                                        index.insert(0,"chain_len = "+ui->lenth_spin->text()+"\n");
                                     }
                                     else
                                     {
                                         index.insert(0,"#chain_len = "+ui->lenth_spin->text()+"\n");
                                     }
                                  }
                                  if (index.contains(QRegExp("t[c]p_read_time_out")))
                                  {
                                      index.remove(0, index.length());
                                      index.insert(0,"tcp_read_time_out "+ui->tcp_read_spin->text()+"\n");
                                  }
                                  if (index.contains(QRegExp("t[c]p_connect_time_out")))
                                  {
                                      index.remove(0, index.length());
                                      index.insert(0,"tcp_connect_time_out "+ui->tcp_con_spin->text()+"\n");
                                  }
                                  if (index.contains(QRegExp("^socks[4]"))  || index.contains(QRegExp("^#socks[4]")) || index.contains(QRegExp("^h[t]tp"))  || index.contains(QRegExp("^#h[t]tp")) || index.contains(QRegExp("^socks[5]"))  || index.contains(QRegExp("^#socks[5]")))
                                  {
                                      index.remove(0, index.length());
                                  }



                                    conf_file.resize(0);
                                    in_conf << index;
                             }
     QTreeWidgetItem* item;
     for (int i = 0; i < ui->treeWidget->topLevelItemCount(); i++)
     {
     item = ui->treeWidget->topLevelItem(i);
     if (item->checkState(0) == Qt::Checked)
     {
     in_conf << item->text(1) + "\t" + item->text(2) + "\t" + item->text(3) + "\t" + item->text(4) + "\t" + item->text(5) + "\n";
     }
     else {
     in_conf << "#" + item->text(1) + "\t" + item->text(2) + "\t" + item->text(3) + "\t" + item->text(4) + "\t" + item->text(5) + "\n";
     }
     }

    }
//qDebug() << pre_release;
conf_file.close();
hide();
}
