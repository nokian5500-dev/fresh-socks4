#ifndef LICENSE_H
#define LICENSE_H

#include <QDialog>


namespace Ui {
    class license;
}

class license : public QDialog {
    Q_OBJECT
public:
    license(QWidget *parent = 0);
    ~license();

protected:
    void changeEvent(QEvent *e);
    void closeEvent(QCloseEvent *event);

private:
    Ui::license *ui;

private slots:
    void on_close_button_clicked();
};

#endif // LICENSE_H
