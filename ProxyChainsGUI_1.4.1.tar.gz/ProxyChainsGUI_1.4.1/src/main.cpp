#include <QtGui/QApplication>
#include "proxychainsgui.h"

int main(int argc, char *argv[])
{
    Q_INIT_RESOURCE(res);
    QApplication a(argc, argv);
    ProxyChainsGui w;
    w.show();
    return a.exec();
}
