#ifndef THREAD_H
#define THREAD_H
#include <QThread>
#include <QProcess>
#include "proxychainsgui.h"

class QProcess;

class ServerThread : public QThread
{
    Q_OBJECT
public:
   ServerThread(QObject *parent = 0);
  ~ServerThread();


protected:
     void run();


private:
    QProcess *process;
};


#endif // TH_STRACE_H
