#ifndef PROXYCHAINSGUI_H
#define PROXYCHAINSGUI_H
#include <QtGui/QCloseEvent>
#include <QMainWindow>
#include <QFileDialog>
#include <QFile>
#include <QListWidgetItem>
#include <QProcess>
#include <QStringList>
#include <QTextStream>
#include <QSystemTrayIcon>
#include <QMenu>
#include <QMessageBox>
#include "thread.h"

extern QString programs;

namespace Ui {
    class ProxyChainsGui;
    class QCloseEvent;
}

class ProxyChainsGui : public QMainWindow {
    Q_OBJECT
public:
    ProxyChainsGui(QWidget *parent = 0);
    ~ProxyChainsGui();
    QString file_path;
    QString output;

protected:
    void changeEvent(QEvent *e);
    void closeEvent(QCloseEvent *event);

private:
    Ui::ProxyChainsGui *ui;
    //QAction *minimizeAction;
    //QAction *maximizeAction;
    QAction *restoreAction;
    QAction *quitAction;
    QAction *settingsAction;
    QAction *aboutAction;
    QAction *addAction;
    QAction *delAction;
    QAction *startAction;
    QAction *startAllAction;
    QSystemTrayIcon *trayIcon;
    QMenu *trayIconMenu;
    QDialog *dSettings;
    QDialog *dAbout;


private slots:
    void startButton();
    void infoButton();
    void settingsButton();
    void startAllButton();
    void exitAct();
    void on_listWidget_doubleClicked(QModelIndex index);
    void delButton();
    void addButton();
    void set_window();
    void about_menu();
    void iconActivated(QSystemTrayIcon::ActivationReason reason);
};

#endif // PROXYCHAINSGUI_H
