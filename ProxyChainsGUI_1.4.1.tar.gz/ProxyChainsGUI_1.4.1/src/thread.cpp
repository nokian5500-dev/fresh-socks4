#include "thread.h"
#include "proxychainsgui.h"
#include <QProcess>
#include <QTextCodec>
#include <QDebug>

QString programs;

ServerThread::ServerThread(QObject *parent) : QThread(parent), process(0)
{
}

ServerThread::~ServerThread()
{
    quit();
    wait();
    delete process;
}

void ServerThread::run()
{
    process = new QProcess;
    process->setProcessChannelMode(QProcess::MergedChannels);
    process->start(programs);
    exec();
}
