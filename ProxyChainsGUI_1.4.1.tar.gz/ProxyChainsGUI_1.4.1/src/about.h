#ifndef ABOUT_H
#define ABOUT_H

#include <QDialog>
#include <QUrl>
#include <QDesktopServices>

namespace Ui {
    class about;
}

class about : public QDialog {
    Q_OBJECT
public:
    about(QWidget *parent = 0);
    ~about();

protected:
    void changeEvent(QEvent *e);
    void closeEvent(QCloseEvent *event);

private:
    Ui::about *ui;
    QDialog *dLicense;

private slots:
    void on_commandLinkButton_2_clicked();
    void on_commandLinkButton_clicked();
    void on_license_button_clicked();
    void on_close_button_clicked();
};

#endif // ABOUT_H
