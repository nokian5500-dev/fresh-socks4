#include "proxychainsgui.h"
#include "ui_proxychainsgui.h"
#include "settings.h"
#include "ui_settings.h"
#include "about.h"
#include "ui_about.h"


ProxyChainsGui::ProxyChainsGui(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ProxyChainsGui)
{
   ui->setupUi(this);
   //******************Create TrayIcon Menu***************************************
   restoreAction = new QAction(tr("&Restore"), this);
   connect(restoreAction, SIGNAL(triggered()), this, SLOT(showNormal()));

   settingsAction = new QAction(tr("&Settings"), this);
   connect(settingsAction, SIGNAL(triggered()), this, SLOT(set_window()));

   quitAction = new QAction(tr("&Quit"), this);
   connect(quitAction, SIGNAL(triggered()), this, SLOT(exitAct()));

   aboutAction = new QAction(tr("&About"), this);
   connect(aboutAction, SIGNAL(triggered()), this, SLOT(about_menu()));

   addAction = new QAction(tr("&Add"), this);
   connect(addAction, SIGNAL(triggered()), this, SLOT(addButton()));

   delAction = new QAction(tr("&Delete"), this);
   connect(delAction, SIGNAL(triggered()), this, SLOT(delButton()));

   startAction = new QAction(tr("&Start"), this);
   connect(startAction, SIGNAL(triggered()), this, SLOT(startButton()));

   startAllAction = new QAction(tr("&Start All"), this);
   connect(startAllAction, SIGNAL(triggered()), this, SLOT(startAllButton()));


   trayIconMenu = new QMenu(this);
   trayIconMenu->addAction(settingsAction);
   settingsAction->setIcon(QIcon(":/images/gconf-editor.svg"));
   settingsAction->setIconVisibleInMenu(true);
   trayIconMenu->addAction(restoreAction);
   restoreAction->setIcon(QIcon(":/images/package-upgrade.svg"));
   restoreAction->setIconVisibleInMenu(true);
   trayIconMenu->addSeparator();
   trayIconMenu->addAction(aboutAction);
   aboutAction->setIcon(QIcon(":/images/gtk-info.svg"));
   aboutAction->setIconVisibleInMenu(true);
   trayIconMenu->addSeparator();
   trayIconMenu->addAction(quitAction);
   quitAction->setIcon(QIcon(":/images/package-purge.png"));
   quitAction->setIconVisibleInMenu(true);

   trayIcon = new QSystemTrayIcon(this);
   trayIcon->setContextMenu(trayIconMenu);

   //********************************************************************************

   ui->mainToolBar->addAction(addAction);
   addAction->setIcon(QIcon(":/images/list-add.svg"));
   ui->mainToolBar->addAction(delAction);
   delAction->setIcon(QIcon(":/images/list-remove.svg"));
   ui->mainToolBar->addSeparator();
   ui->mainToolBar->addAction(startAction);
   startAction->setIcon(QIcon(":/images/dialog-apply.svg"));
   ui->mainToolBar->addAction(startAllAction);
   startAllAction->setIcon(QIcon(":/images/dialog-apply1.png"));
   ui->mainToolBar->addSeparator();
   ui->mainToolBar->addAction(settingsAction);
   ui->mainToolBar->addAction(aboutAction);
   ui->mainToolBar->addAction(quitAction);

   connect(trayIcon, SIGNAL(activated(QSystemTrayIcon::ActivationReason)),
           this, SLOT(iconActivated(QSystemTrayIcon::ActivationReason)));

   trayIcon->setIcon(QIcon(":/images/icon.png"));
   setWindowIcon(QIcon(":/images/icon.png"));
   trayIcon->show();
    dSettings = new settings (this);
    dAbout = new about (this);

   QFile inputFile(QDir::homePath() + "/.progs.dat");
   if (!inputFile.open(QIODevice::ReadOnly))
   return;
   QTextStream in(&inputFile);
          if (inputFile.exists())
   {
               while (!in.atEnd())
               {

               QListWidgetItem * item = new QListWidgetItem;
               QString line = in.readLine();
               ui->listWidget->addItem(item);
               QString item_name = QFileInfo (line).baseName();
               item->setText(item_name);
               item->setIcon(QIcon::fromTheme(item_name, QIcon(":/images/exec.png")));
               item->icon().actualSize(QSize(32, 32));
               }
           }
          
           }

ProxyChainsGui::~ProxyChainsGui()
{
    delete ui;
}

void ProxyChainsGui::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}


void ProxyChainsGui::addButton()
{
    QListWidgetItem * item = new QListWidgetItem;
    QString item_path = QFileDialog::getOpenFileName(this, tr("Add application"), "/", tr("*"));
    if (item_path.length() > 4)
    {
    ui->listWidget->addItem(item);
    QString item_name = QFileInfo (item_path).baseName();
    item->setText(item_name);
    item->setIcon(QIcon::fromTheme(item_name, QIcon(":/images/exec.png")));
    item->icon().actualSize(QSize(32, 32));
    }
}

void ProxyChainsGui::delButton()
{
    delete ui->listWidget->takeItem(ui->listWidget->currentRow());
}

void ProxyChainsGui::on_listWidget_doubleClicked(QModelIndex)
{
    programs = "proxychains "+ui->listWidget->item(ui->listWidget->currentRow())->text();
    ServerThread *the = new ServerThread;
    the->start();
}

void ProxyChainsGui::closeEvent(QCloseEvent *event)
{
    if (trayIcon->isVisible()) {
        QMessageBox::information(this, tr("Systray"),
                                 tr("The program will keep running in the "
                                    "system tray. To terminate the program, "
                                    "choose <b>Quit</b> in the context menu "
                                    "that pops up when clicking this program's "
                                    "entry in the system tray."));
        hide();
        event->ignore();
    }

}

void ProxyChainsGui::startAllButton()
{
    if (ui->listWidget->count() != 0)
    {
    for (int i = 0; i < ui->listWidget->count(); i++)
    {
    ui->listWidget->setCurrentRow(i);
    programs = ui->listWidget->item(ui->listWidget->currentRow())->text();
    ServerThread *the = new ServerThread;
    the->start();
    }
}
}

void ProxyChainsGui::iconActivated(QSystemTrayIcon::ActivationReason reason)
{
    switch (reason) {
        case QSystemTrayIcon::Trigger:
        case QSystemTrayIcon::DoubleClick:
         show();
            break;
        case QSystemTrayIcon::MiddleClick:
            break;
        default:
        ;
    }
}

void ProxyChainsGui::settingsButton()
{
 set_window();
}

void ProxyChainsGui::set_window()
{
    dSettings->show();
}

\
void ProxyChainsGui::about_menu()
{
    dAbout->show();
}

void ProxyChainsGui::exitAct()
{
    QFile file(QDir::homePath() + "/.progs.dat");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
    return;
    QTextStream out(&file);
    for (int j = 0; j < ui->listWidget->count(); ++j)
            {
                ui->listWidget->setCurrentRow(j);
                output = ui->listWidget->item(ui->listWidget->currentRow())->text();
                out << output+"\n";
            }
    QApplication::exit();
}

void ProxyChainsGui::infoButton()
{
   dAbout->show();
}

void ProxyChainsGui::startButton()
{
    if (ui->listWidget->count() != 0)
    {
    programs = ui->listWidget->item(ui->listWidget->currentRow())->text();
    ServerThread *the = new ServerThread;
    the->start();
    }
}
