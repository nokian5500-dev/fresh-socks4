#include "license.h"
#include "ui_license.h"
#include "about.h"
#include "ui_about.h"
#include "proxychainsgui.h"
#include "ui_proxychainsgui.h"

license::license(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::license)
{
    ui->setupUi(this);
}

license::~license()
{
    delete ui;
}

void license::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void license::closeEvent(QCloseEvent *ev)
{
        hide();
        ev->ignore();
}

void license::on_close_button_clicked()
{
    hide();
}
