#ifndef SETTINGS_H
#define SETTINGS_H

#include <QDialog>
#include <QtGui/QCloseEvent>
#include <QMainWindow>
#include <QFileDialog>
#include <QFile>
#include <QListWidgetItem>
#include <QProcess>
#include <QStringList>
#include <QTextStream>
#include <QSystemTrayIcon>
#include <QMenu>
#include <QDebug>
#include <QTreeWidget>
#include <QComboBox>


namespace Ui {
    class settings;
    class QCloseEvent;
}

class settings : public QDialog {
    Q_OBJECT
public:
    Ui::settings *ui;
    settings(QWidget* pParent = 0);
    ~settings();

    QByteArray config_file;

protected:
    void changeEvent(QEvent *e);
    void closeEvent(QCloseEvent *event);

private:
    QAction *ComboAction;

private slots:


private slots:
    void on_save_button_clicked();
    void on_dynamic_radio_pressed();
    void on_strict_radio_pressed();
    void on_random_radio_pressed();
    void on_del_button_clicked();
    void on_add_button_clicked();
};

#endif // SETTINGS_H
